bl_info = {
    "name": "pommelstrike's DDS Channel Splitter",
    "author": "pommelstrike",
    "version": (1, 1, 6),
    "blender": (4, 1, 1),  # Updated Blender version requirement
    "location": "3D View (Sidebar) & 3D View Header",
    "description": ("*Use the 3D View Header Hot Bar (click 'DDS RGBA Splitter') to open a popover containing buttons for splitting DDS channels "
                    "and toggling the System Console. Also, a panel is available in the 3D View Sidebar. Supports _NM, _PM, _BM, _GM, and _MSKcloth files with separate channel outputs."),
    "category": "Import-Export",
    "url": "https://linktr.ee/pommelstrike",
}

import bpy, os, glob

# -----------------------------------------------------------
# MAPPING for Skin Textures
# -----------------------------------------------------------
MAPPING = {
    "HMVY": {"R": "L0_HMVY_Red_Hemo", "G": "L1_HMVY_Grn_Mela", "B": "L2_HMVY_Blu_Vein", "A": "L3_HMVY_Alpha_Yellow"},
    "CLEA": {"R": "L4_CLEA_Red_Cavity", "G": "L5_CLEA_Grn_Brows", "B": "L6_CLEA_Blu_Lips", "A": "A0_CLEA_Alpha"},
    "MSK":  {"R": "L7_MSK_Red_horns_nail", "G": "L8_MSK_Grn_Pigment", "B": "L9_MSK_Blu_TearLip"}
}

# -----------------------------------------------------------
# Operator: Split DDS Channels (File Processing)
# -----------------------------------------------------------
class DDS_OT_SplitChannels(bpy.types.Operator):
    bl_idname = "dds.split_channels"
    bl_label = "Split DDS Channels"
    bl_description = "Split all DDS in folder into greyscale TGA files with custom naming"
    
    def execute(self, context):
        src_dir = bpy.path.abspath(context.scene.dds_folder)
        if not os.path.isdir(src_dir):
            self.report({'ERROR'}, f"Invalid directory: {src_dir}")
            return {'CANCELLED'}
        out_dir = os.path.join(src_dir, "split-output")
        os.makedirs(out_dir, exist_ok=True)
        
        files = glob.glob(os.path.join(src_dir, "*.dds"))
        total = len(files)
        wm = context.window_manager
        wm.progress_begin(0, total)
        
        for idx, filepath in enumerate(files):
            wm.progress_update(idx)
            base = os.path.splitext(os.path.basename(filepath))[0]
            # Extract the key based on the text after the last underscore, and convert to uppercase.
            key = base.rsplit('_', 1)[-1].upper()
            
            # Armor Textures (Normal Maps)
            if key == "NM":
                try:
                    img = bpy.data.images.load(filepath)
                    w, h = img.size
                    pixels = list(img.pixels)
                    
                    # Process each channel for normal maps
                    for channel, idx_chan, out_name in zip(("R", "G", "B", "A"), (0, 1, 2, 3), ("Nrm_R", "Nrm_G", "Nrm_B", "Nrm_A")):
                        new_img = bpy.data.images.new(out_name, width=w, height=h)
                        new_pixels = [0.0] * (w * h * 4)
                        for i in range(w * h):
                            val = pixels[i*4 + idx_chan]
                            new_pixels[i*4:i*4+4] = (val, val, val, 1.0)
                        new_img.pixels = new_pixels
                        out_path = os.path.join(out_dir, f"{out_name}.tga")
                        new_img.filepath_raw = out_path
                        new_img.file_format = 'TARGA'
                        new_img.save()
                        bpy.data.images.remove(new_img)
                    
                    bpy.data.images.remove(img)
                    self.report({'INFO'}, f"Processed {base} (NM custom)")
                except Exception as e:
                    self.report({'ERROR'}, f"Failed {base}: {e}")
                continue
            
            elif key == "PM":
                try:
                    img = bpy.data.images.load(filepath)
                    w, h = img.size
                    pixels = list(img.pixels)
                    
                    # PM_R_Metallic from red (index 0)
                    new_img = bpy.data.images.new("PM_R_Metallic", width=w, height=h)
                    new_pixels = [0.0] * (w * h * 4)
                    for i in range(w * h):
                        val = pixels[i*4+0]
                        new_pixels[i*4:i*4+4] = (val, val, val, 1.0)
                    new_img.pixels = new_pixels
                    out_path = os.path.join(out_dir, "PM_R_Metallic.tga")
                    new_img.filepath_raw = out_path
                    new_img.file_format = 'TARGA'
                    new_img.save()
                    bpy.data.images.remove(new_img)
                    
                    # PM_G_Roughness from green (index 1)
                    new_img = bpy.data.images.new("PM_G_Roughness", width=w, height=h)
                    new_pixels = [0.0] * (w * h * 4)
                    for i in range(w * h):
                        val = pixels[i*4+1]
                        new_pixels[i*4:i*4+4] = (val, val, val, 1.0)
                    new_img.pixels = new_pixels
                    out_path = os.path.join(out_dir, "PM_G_Roughness.tga")
                    new_img.filepath_raw = out_path
                    new_img.file_format = 'TARGA'
                    new_img.save()
                    bpy.data.images.remove(new_img)
                    
                    # PM_B_Ambient_Occlusion from blue (index 2)
                    new_img = bpy.data.images.new("PM_B_Ambient_Occlusion", width=w, height=h)
                    new_pixels = [0.0] * (w * h * 4)
                    for i in range(w * h):
                        val = pixels[i*4+2]
                        new_pixels[i*4:i*4+4] = (val, val, val, 1.0)
                    new_img.pixels = new_pixels
                    out_path = os.path.join(out_dir, "PM_B_Ambient_Occlusion.tga")
                    new_img.filepath_raw = out_path
                    new_img.file_format = 'TARGA'
                    new_img.save()
                    bpy.data.images.remove(new_img)
                    
                    bpy.data.images.remove(img)
                    self.report({'INFO'}, f"Processed {base} (PM custom)")
                except Exception as e:
                    self.report({'ERROR'}, f"Failed {base}: {e}")
                continue
            
            elif key == "BM":
                try:
                    img = bpy.data.images.load(filepath)
                    w, h = img.size
                    pixels = list(img.pixels)
                    
                    # BM_A_Opacity from alpha (index 3)
                    new_img = bpy.data.images.new("BM_A_Opacity", width=w, height=h)
                    new_pixels = [0.0] * (w * h * 4)
                    for i in range(w * h):
                        val = pixels[i*4+3]
                        new_pixels[i*4:i*4+4] = (val, val, val, 1.0)
                    new_img.pixels = new_pixels
                    out_path = os.path.join(out_dir, "BM_A_Opacity.tga")
                    new_img.filepath_raw = out_path
                    new_img.file_format = 'TARGA'
                    new_img.save()
                    bpy.data.images.remove(new_img)
                    
                    bpy.data.images.remove(img)
                    self.report({'INFO'}, f"Processed {base} (BM custom)")
                except Exception as e:
                    self.report({'ERROR'}, f"Failed {base}: {e}")
                continue

            # ------------------------------
            # New Branch for MSKcloth Files
            # ------------------------------
            elif key == "MSKCLOTH":
                try:
                    img = bpy.data.images.load(filepath)
                    w, h = img.size
                    pixels = list(img.pixels)
                    # Process R, G, and B channels only.
                    for chan, idx_chan in zip(("R", "G", "B"), (0, 1, 2)):
                        new_img = bpy.data.images.new(f"MSKcloth_{chan}", width=w, height=h)
                        new_pixels = [0.0] * (w * h * 4)
                        for i in range(w * h):
                            val = pixels[i*4+idx_chan]
                            new_pixels[i*4:i*4+4] = (val, val, val, 1.0)
                        new_img.pixels = new_pixels
                        out_path = os.path.join(out_dir, f"MSKcloth_{chan}.tga")
                        new_img.filepath_raw = out_path
                        new_img.file_format = 'TARGA'
                        new_img.save()
                        bpy.data.images.remove(new_img)
                    bpy.data.images.remove(img)
                    self.report({'INFO'}, f"Processed {base} (MSKcloth custom)")
                except Exception as e:
                    self.report({'ERROR'}, f"Failed {base}: {e}")
                continue

            # Handle GM files specially (Glow Maps)
            elif key == "GM":
                try:
                    img = bpy.data.images.load(filepath)
                    w, h = img.size
                    pixels = list(img.pixels)
                    # Process each channel: R, G, B, A
                    for chan, idx_chan in zip(("R", "G", "B", "A"), (0, 1, 2, 3)):
                        new_img = bpy.data.images.new(f"{base}_GM_{chan}", width=w, height=h)
                        new_pixels = [0.0] * (w * h * 4)
                        for i in range(w * h):
                            val = pixels[i*4+idx_chan]
                            new_pixels[i*4:i*4+4] = (val, val, val, 1.0)
                        new_img.pixels = new_pixels
                        out_path = os.path.join(out_dir, f"{base}_GM_{chan}.tga")
                        new_img.filepath_raw = out_path
                        new_img.file_format = 'TARGA'
                        new_img.save()
                        bpy.data.images.remove(new_img)
                    bpy.data.images.remove(img)
                    self.report({'INFO'}, f"Processed {base} (GM custom)")
                except Exception as e:
                    self.report({'ERROR'}, f"Failed {base}: {e}")
                continue
            
            # Skin Textures (standard mapping)
            elif key not in MAPPING:
                self.report({'INFO'}, f"Skipping {base}: no naming mapping defined.")
                continue
            else:
                try:
                    img = bpy.data.images.load(filepath)
                    w, h = img.size
                    pixels = list(img.pixels)
                    for chan, name in MAPPING[key].items():
                        new_img = bpy.data.images.new(name, width=w, height=h)
                        new_pixels = [0.0] * (w * h * 4)
                        idx_chan = {'R': 0, 'G': 1, 'B': 2, 'A': 3}[chan]
                        for i in range(w * h):
                            val = pixels[i*4+idx_chan]
                            new_pixels[i*4:i*4+4] = (val, val, val, 1.0)
                        new_img.pixels = new_pixels
                        out_path = os.path.join(out_dir, f"{name}.tga")
                        new_img.filepath_raw = out_path
                        new_img.file_format = 'TARGA'
                        new_img.save()
                        bpy.data.images.remove(new_img)
                    bpy.data.images.remove(img)
                    self.report({'INFO'}, f"Processed {base}")
                except Exception as e:
                    self.report({'ERROR'}, f"Failed {base}: {e}")
        wm.progress_end()
        return {'FINISHED'}

# -----------------------------------------------------------
# Popover Panel for the Hot Bar
# -----------------------------------------------------------
class POMMELSTRIKE_PT_HotBar(bpy.types.Panel):
    bl_label = "DDS RGBA Splitter"
    bl_idname = "POMMELSTRIKE_PT_HotBar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'  # Popover panels remain in the WINDOW region
    
    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "dds_folder")
        layout.operator("dds.split_channels", text="Split Channels")
        layout.operator("wm.console_toggle", text="View System Console")

# -----------------------------------------------------------
# Header Draw Callback to add Popover Button next to transform orientations
# -----------------------------------------------------------
def pommelstrike_add_to_view3d_ht_tool_header(self, context):
    layout = self.layout
    # Create an aligned row to group header elements together.
    row = layout.row(align=True)
    row.popover(panel="POMMELSTRIKE_PT_HotBar", text="DDS RGBA Splitter", icon="COLORSET_10_VEC")

# -----------------------------------------------------------
# Panel: 3D View Sidebar Panel (Alternative UI)
# -----------------------------------------------------------
class POMMELSTRIKE_PT_3DViewPanel(bpy.types.Panel):
    bl_label = "Pommelstrike DDS Splitter"
    bl_idname = "POMMELSTRIKE_PT_3DViewPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'  # Sidebar (N-panel)
    bl_category = "Pommelstrike"  # Unique category name
     
    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "dds_folder")
        layout.operator("dds.split_channels", text="Split Channels")
        layout.operator("wm.console_toggle", text="View System Console")

# -----------------------------------------------------------
# Registration
# -----------------------------------------------------------
classes = (
    DDS_OT_SplitChannels,
    POMMELSTRIKE_PT_HotBar,
    POMMELSTRIKE_PT_3DViewPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.dds_folder = bpy.props.StringProperty(name="DDS Folder", subtype='DIR_PATH')
    bpy.types.VIEW3D_HT_header.append(pommelstrike_add_to_view3d_ht_tool_header)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.dds_folder
    bpy.types.VIEW3D_HT_header.remove(pommelstrike_add_to_view3d_ht_tool_header)

if __name__ == "__main__":
    register()
